from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user
from .. import models, schemas

router = APIRouter(prefix="/users", tags=["users"])


@router.get("/me", response_model=schemas.UserOut)
def me(current_user=Depends(get_current_user)):
    return current_user


@router.get("/me/progress", response_model=list[schemas.UserCardProgressOut])
def get_my_progress(
    deck_id: int,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    # Optional: verify deck exists
    deck = db.query(models.Deck).filter(models.Deck.id == deck_id).first()
    if not deck:
        raise HTTPException(status_code=404, detail="Deck not found")

    # Return all progress rows for cards in this deck for this user
    progress = (
        db.query(models.UserCardProgress)
        .join(models.Card, models.Card.id == models.UserCardProgress.card_id)
        .filter(models.UserCardProgress.user_id == current_user.id)
        .filter(models.Card.deck_id == deck_id)
        .all()
    )
    return progress

"""
@router.delete("/me/progress", response_model=schemas.ProgressResetOut)
def reset_my_progress(
    deck_id: int,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    deck = db.query(models.Deck).filter(models.Deck.id == deck_id).first()
    if not deck:
        raise HTTPException(status_code=404, detail="Deck not found")

    # Delete progress rows for this user's cards in this deck
    q = (
        db.query(models.UserCardProgress)
        .join(models.Card, models.Card.id == models.UserCardProgress.card_id)
        .filter(models.UserCardProgress.user_id == current_user.id)
        .filter(models.Card.deck_id == deck_id)
    )

    deleted = q.delete(synchronize_session=False)
    db.commit()

    return schemas.ProgressResetOut(
        user_id=current_user.id,
        deck_id=deck_id,
        deleted=deleted,
    )
"""