
from __future__ import annotations
from fastapi import HTTPException
from pydantic import BaseModel, ConfigDict, Field
from datetime import datetime
from typing import Optional, List, Generic, TypeVar


# ----------------- CARD SECTION -----------------

class CardBase(BaseModel):
    front: str
    back: str
    example_sentence: Optional[str] = None


class CardCreate(CardBase):
    pass


class CardUpdate(BaseModel):
    front: Optional[str] = None
    back: Optional[str] = None
    example_sentence: Optional[str] = None


class CardOut(CardBase):
    id: int
    deck_id: int
    model_config = ConfigDict(from_attributes=True)


class InboxWordIn(BaseModel):
    front: str = Field(min_length=1, max_length=200)
    back: Optional[str] = Field(default=None, max_length=500)
    example_sentence: Optional[str] = Field(default=None, max_length=500)

    # optional: allow client to define languages for Inbox creation
    source_language_id: Optional[int] = None
    target_language_id: Optional[int] = None

class InboxWordOut(BaseModel):
    deck_id: int
    card: CardOut 


class InboxBulkIn(BaseModel):
    text: str = Field(..., examples=[""])
    delimiter: Optional[str] = Field(default=None, examples=["—", "-", ":", "	"])
    # Optional: if user's defaults are not set yet, you may pass language IDs here.
    source_language_id: Optional[int] = Field(default=None, ge=1)
    target_language_id: Optional[int] = Field(default=None, ge=1)
    dry_run: bool = False

class BulkItemResult(BaseModel):
    line: str
    status: str  # "created" | "skipped" | "failed"
    reason: Optional[str] = None
    card_id: Optional[int] = None

class InboxBulkOut(BaseModel):
    deck_id: int
    created: int
    skipped: int
    failed: int
    results: List[BulkItemResult]



# --------------- LANGUAGE SECTION -------------------

class LanguageBase(BaseModel):
    name: str
    code: Optional[str] = None


class LanguageCreate(LanguageBase):
    pass


class LanguageUpdate(BaseModel):
    name: Optional[str] = None
    code: Optional[str] = None


class LanguageOut(LanguageBase):
    id: int
    model_config = ConfigDict(from_attributes=True)


# ----------------- DECK SECTION -----------------

class DeckBase(BaseModel):
    name: str
    source_language_id: int
    target_language_id: int


class DeckCreate(DeckBase):
    pass


class DeckOut(DeckBase):
    id: int
    is_public: bool = False
    status: str = "draft"
    shared_code: Optional[str] = None
    model_config = ConfigDict(from_attributes=True, use_enum_values=True)


# ----------------- USER SECTION -----------------

class RegisterIn(BaseModel):
    username: str
    password: str = Field(min_length=1, max_length=64)


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserOut(BaseModel):
    id: int
    username: str
    default_source_language_id: Optional[int] = None
    default_target_language_id: Optional[int] = None
    model_config = ConfigDict(from_attributes=True)


class UserLanguageDefaultsIn(BaseModel):
    default_source_language_id: int = Field(ge=1)
    default_target_language_id: int = Field(ge=1)


# ----------------- STUDY / PROGRESS -----------------

class UserCardProgressOut(BaseModel):
    user_id: int
    card_id: int
    times_seen: int
    times_correct: int
    status: str

    ease_factor: Optional[float] = None
    interval_days: Optional[int] = None
    repetitions: Optional[int] = None
    last_review: Optional[datetime] = None
    next_review: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


class StudyAnswerIn(BaseModel):
    correct: Optional[bool] = None
    quality: Optional[int] = Field(default=None, ge=0, le=5)


class StudyBatchOut(BaseModel):
    deck_id: int
    count: int
    cards: List[CardOut]


class StudyStatusOut(BaseModel):
    deck_id: int
    due_count: int
    new_available_count: int
    reviewed_today: int
    new_introduced_today: int
    remaining_review_quota: int
    remaining_new_quota: int
    next_due_at: Optional[datetime] = None

T = TypeVar("T")

class PageMeta(BaseModel):
    limit: int 
    offset: int 
    total: int 
    has_more: bool

class Page(BaseModel, Generic[T]):
    items: List[T]
    meta: PageMeta